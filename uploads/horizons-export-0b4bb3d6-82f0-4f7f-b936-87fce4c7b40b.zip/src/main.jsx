import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { AuthProvider } from '@/contexts/AuthContext';
import { CartProvider } from '@/contexts/CartContext';
import { PointsProvider } from '@/contexts/PointsContext';
import { CommunityProvider } from '@/contexts/CommunityContext';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <PointsProvider>
        <CommunityProvider>
          <CartProvider>
            <App />
          </CartProvider>
        </CommunityProvider>
      </PointsProvider>
    </AuthProvider>
  </React.StrictMode>
);
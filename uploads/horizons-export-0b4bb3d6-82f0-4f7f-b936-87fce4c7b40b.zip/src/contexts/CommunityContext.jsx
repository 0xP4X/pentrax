import React, { createContext, useState, useContext, useEffect } from 'react';
import { discussions as initialDiscussions } from '@/data/communityData';
import { useAuth } from './AuthContext';

const CommunityContext = createContext(null);

const getInitialState = () => {
  try {
    const item = window.localStorage.getItem('pentrax-community-discussions');
    return item ? JSON.parse(item) : initialDiscussions;
  } catch (error) {
    console.error(error);
    return initialDiscussions;
  }
};

export const CommunityProvider = ({ children }) => {
  const [discussions, setDiscussions] = useState(getInitialState);
  const { user } = useAuth();

  useEffect(() => {
    window.localStorage.setItem('pentrax-community-discussions', JSON.stringify(discussions));
  }, [discussions]);

  const getDiscussion = (id) => {
    return discussions.find(d => d.id === parseInt(id));
  };

  const addDiscussion = (title, content) => {
    if (!user) return;
    const newDiscussion = {
      id: Date.now(),
      title,
      content,
      author: user.username,
      authorLevel: 'Beginner',
      category: 'General',
      replies: 0,
      likes: 0,
      views: 1,
      timeAgo: 'Just now',
      isHot: false,
      tags: ['New'],
      comments: [],
      likedBy: [],
      savedBy: [],
    };
    setDiscussions(prev => [newDiscussion, ...prev]);
  };

  const toggleLike = (discussionId) => {
    if (!user) return;
    setDiscussions(prev =>
      prev.map(d => {
        if (d.id === discussionId) {
          const likedBy = d.likedBy || [];
          const isLiked = likedBy.includes(user.username);
          const newLikedBy = isLiked ? likedBy.filter(u => u !== user.username) : [...likedBy, user.username];
          return { ...d, likes: newLikedBy.length, likedBy: newLikedBy };
        }
        return d;
      })
    );
  };
  
  const isLiked = (discussionId) => {
    if (!user) return false;
    const discussion = discussions.find(d => d.id === discussionId);
    return discussion?.likedBy?.includes(user.username);
  }

  const toggleSave = (discussionId) => {
    if (!user) return;
    setDiscussions(prev =>
      prev.map(d => {
        if (d.id === discussionId) {
          const savedBy = d.savedBy || [];
          const isSaved = savedBy.includes(user.username);
          const newSavedBy = isSaved ? savedBy.filter(u => u !== user.username) : [...savedBy, user.username];
          return { ...d, savedBy: newSavedBy };
        }
        return d;
      })
    );
  };

  const isSaved = (discussionId) => {
    if (!user) return false;
    const discussion = discussions.find(d => d.id === discussionId);
    return discussion?.savedBy?.includes(user.username);
  }

  const addComment = (discussionId, text) => {
    if (!user) return;
    const newComment = {
      id: Date.now(),
      author: user.username,
      text,
      timeAgo: 'Just now'
    };
    setDiscussions(prev =>
      prev.map(d => {
        if (d.id === discussionId) {
          const comments = d.comments || [];
          const newComments = [...comments, newComment];
          return { ...d, comments: newComments, replies: newComments.length };
        }
        return d;
      })
    );
  };

  const value = { discussions, setDiscussions, getDiscussion, addDiscussion, toggleLike, isLiked, toggleSave, isSaved, addComment };

  return <CommunityContext.Provider value={value}>{children}</CommunityContext.Provider>;
};

export const useCommunity = () => {
  return useContext(CommunityContext);
};
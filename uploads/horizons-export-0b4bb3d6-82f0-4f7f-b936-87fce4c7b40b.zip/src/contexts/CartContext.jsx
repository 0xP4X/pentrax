import React, { createContext, useState, useContext, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);
  const [likedItems, setLikedItems] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const storedCart = localStorage.getItem('pentrax-cart');
    if (storedCart) setCartItems(JSON.parse(storedCart));
    const storedLiked = localStorage.getItem('pentrax-liked');
    if (storedLiked) setLikedItems(JSON.parse(storedLiked));
  }, []);

  const updateLocalStorage = (key, items) => {
    localStorage.setItem(key, JSON.stringify(items));
  };

  const addToCart = (tool) => {
    setCartItems(prevItems => {
      const isItemInCart = prevItems.find(item => item.id === tool.id);
      if (isItemInCart) {
        toast({ title: "Already in Cart", description: `${tool.name} is already in your cart.` });
        return prevItems;
      } else {
        toast({ title: "Added to Cart", description: `${tool.name} has been added to your cart.` });
        const newItems = [...prevItems, tool];
        updateLocalStorage('pentrax-cart', newItems);
        return newItems;
      }
    });
  };

  const toggleLike = (tool) => {
    setLikedItems(prevItems => {
      const isLiked = prevItems.find(item => item.id === tool.id);
      let newItems;
      if (isLiked) {
        newItems = prevItems.filter(item => item.id !== tool.id);
        toast({ title: "Unliked", description: `${tool.name} removed from your liked items.` });
      } else {
        newItems = [...prevItems, tool];
        toast({ title: "Liked!", description: `${tool.name} added to your liked items.` });
      }
      updateLocalStorage('pentrax-liked', newItems);
      return newItems;
    });
  };

  const isLiked = (toolId) => !!likedItems.find(item => item.id === toolId);

  return (
    <CartContext.Provider value={{ cartItems, likedItems, addToCart, toggleLike, isLiked }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  return useContext(CartContext);
};
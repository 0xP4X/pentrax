import React, { createContext, useState, useContext, useEffect } from 'react';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [isNewUser, setIsNewUser] = useState(false);

  useEffect(() => {
    const storedUser = localStorage.getItem('pentrax-user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (username) => {
    const existingUsers = JSON.parse(localStorage.getItem('pentrax-users') || '[]');
    if (!existingUsers.includes(username)) {
      setIsNewUser(true);
      localStorage.setItem('pentrax-users', JSON.stringify([...existingUsers, username]));
    } else {
      setIsNewUser(false);
    }
    
    const isAdmin = username.toLowerCase() === 'admin';
    const userData = { username, isAdmin };
    setUser(userData);
    localStorage.setItem('pentrax-user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('pentrax-user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isNewUser, setIsNewUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  return useContext(AuthContext);
};
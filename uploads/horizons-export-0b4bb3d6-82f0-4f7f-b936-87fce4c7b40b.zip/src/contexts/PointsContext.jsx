import React, { createContext, useState, useContext, useEffect } from 'react';
import { useAuth } from './AuthContext';

const PointsContext = createContext(null);

export const PointsProvider = ({ children }) => {
  const [points, setPoints] = useState(0);
  const [history, setHistory] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      const storedPoints = localStorage.getItem(`pentrax-points-${user.username}`);
      const storedHistory = localStorage.getItem(`pentrax-history-${user.username}`);
      if (storedPoints) setPoints(JSON.parse(storedPoints));
      if (storedHistory) setHistory(JSON.parse(storedHistory));
    } else {
      setPoints(0);
      setHistory([]);
    }
  }, [user]);

  const addPoints = (amount, reason) => {
    if (!user) return;
    const newPoints = points + amount;
    const newHistoryEntry = { amount, reason, date: new Date().toISOString() };
    const newHistory = [newHistoryEntry, ...history];
    
    setPoints(newPoints);
    setHistory(newHistory);

    localStorage.setItem(`pentrax-points-${user.username}`, JSON.stringify(newPoints));
    localStorage.setItem(`pentrax-history-${user.username}`, JSON.stringify(newHistory));
  };

  return (
    <PointsContext.Provider value={{ points, history, addPoints }}>
      {children}
    </PointsContext.Provider>
  );
};

export const usePoints = () => {
  return useContext(PointsContext);
};
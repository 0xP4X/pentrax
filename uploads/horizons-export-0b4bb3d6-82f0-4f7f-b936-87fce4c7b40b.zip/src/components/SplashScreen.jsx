
import React from 'react';
import { motion } from 'framer-motion';
import { Zap, Shield, Terminal, Lock } from 'lucide-react';

const SplashScreen = () => {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-black via-gray-900 to-black flex items-center justify-center z-50 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,255,136,0.1),transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(0,204,255,0.1),transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(255,0,128,0.1),transparent_70%)]" />
      
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 text-center"
      >
        <motion.div
          initial={{ y: -50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="flex items-center justify-center mb-8"
        >
          <div className="relative">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 rounded-full border-2 border-transparent bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 p-1"
            >
              <div className="w-20 h-20 rounded-full bg-black" />
            </motion.div>
            <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-blue-400 flex items-center justify-center">
              <Zap className="w-10 h-10 text-black" />
            </div>
          </div>
        </motion.div>

        <motion.h1
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="text-6xl md:text-8xl font-bold mb-4 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent"
        >
          PentraX
        </motion.h1>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.9, duration: 0.6 }}
          className="text-xl md:text-2xl text-gray-300 mb-8 font-light"
        >
          Cybersecurity & Ethical Hacking Hub
        </motion.p>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="flex justify-center space-x-8 mb-8"
        >
          {[
            { icon: Shield, delay: 0 },
            { icon: Terminal, delay: 0.2 },
            { icon: Lock, delay: 0.4 }
          ].map(({ icon: Icon, delay }, index) => (
            <motion.div
              key={index}
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 1.2 + delay, duration: 0.5, type: "spring" }}
              className="w-12 h-12 rounded-full bg-gradient-to-r from-green-400/20 to-blue-400/20 flex items-center justify-center border border-green-400/30"
            >
              <Icon className="w-6 h-6 text-green-400" />
            </motion.div>
          ))}
        </motion.div>

        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ delay: 1.8, duration: 1.2, ease: "easeInOut" }}
          className="w-64 h-1 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 rounded-full mx-auto"
        />

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2.5, duration: 0.5 }}
          className="text-sm text-gray-500 mt-8"
        >
          Loading your security environment...
        </motion.p>
      </motion.div>

      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400">
        <motion.div
          initial={{ width: "0%" }}
          animate={{ width: "100%" }}
          transition={{ duration: 3, ease: "easeInOut" }}
          className="h-full bg-white/20"
        />
      </div>
    </div>
  );
};

export default SplashScreen;

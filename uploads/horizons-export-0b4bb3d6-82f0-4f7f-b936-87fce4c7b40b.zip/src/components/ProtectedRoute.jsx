import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const ProtectedRoute = () => {
  const { user } = useAuth();
  const { toast } = useToast();

  if (!user) {
    toast({
      title: "Authentication Required",
      description: "You need to be logged in to access this page.",
      variant: "destructive",
    });
    return <Navigate to="/login" />;
  }

  return <Outlet />;
};

export default ProtectedRoute;
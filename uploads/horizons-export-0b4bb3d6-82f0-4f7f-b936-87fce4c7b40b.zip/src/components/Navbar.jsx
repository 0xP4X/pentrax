import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Shield, 
  Terminal, 
  Users, 
  ShoppingBag, 
  User, 
  Moon, 
  Sun,
  Menu,
  X,
  Zap,
  ShoppingCart,
  LogOut,
  Heart,
  LayoutDashboard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';

const Navbar = ({ darkMode, setDarkMode }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { user, logout } = useAuth();
  const { cartItems, likedItems } = useCart();

  const navItems = [
    { path: '/', label: 'Dashboard', icon: Shield },
    { path: '/labs', label: 'Labs', icon: Terminal },
    { path: '/marketplace', label: 'Marketplace', icon: ShoppingBag },
    { path: '/community', label: 'Community', icon: Users },
  ];

  if (user) {
    navItems.push({ path: '/profile', label: 'Profile', icon: User });
  }
  if (user?.isAdmin) {
    navItems.push({ path: '/admin', label: 'Admin', icon: LayoutDashboard });
  }

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed top-0 left-0 right-0 z-50 glass-effect border-b"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link to="/" className="flex items-center space-x-2">
            <div className="relative"><Zap className="h-8 w-8 text-green-400" /><div className="absolute inset-0 h-8 w-8 text-green-400 animate-pulse opacity-50"><Zap className="h-8 w-8" /></div></div>
            <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">PentraX</span>
          </Link>

          <div className="hidden md:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path} className={`flex items-center space-x-2 px-3 py-2 rounded-lg transition-all duration-200 ${isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                  <Icon className="h-4 w-4" />
                  <span className="text-sm font-medium">{item.label}</span>
                </Link>
              );
            })}
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" onClick={() => setDarkMode(!darkMode)} className="h-9 w-9">{darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}</Button>

            <Popover>
              <PopoverTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 relative">
                  <ShoppingCart className="h-4 w-4" />
                  {(cartItems.length > 0 || likedItems.length > 0) && (
                    <span className="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                      {cartItems.length + likedItems.length}
                    </span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80">
                <div className="grid gap-4">
                  <div className="space-y-2"><h4 className="font-medium leading-none">My Items</h4><p className="text-sm text-muted-foreground">Your cart and liked items.</p></div>
                  <div className="grid gap-2">
                    <div className="flex items-center font-semibold"><ShoppingCart className="mr-2 h-4 w-4" /> Cart ({cartItems.length})</div>
                    {cartItems.length > 0 ? cartItems.map(item => <div key={item.id} className="text-sm">{item.name}</div>) : <p className="text-sm text-muted-foreground">Your cart is empty.</p>}
                    <Separator className="my-2" />
                    <div className="flex items-center font-semibold"><Heart className="mr-2 h-4 w-4" /> Liked ({likedItems.length})</div>
                    {likedItems.length > 0 ? likedItems.map(item => <div key={item.id} className="text-sm">{item.name}</div>) : <p className="text-sm text-muted-foreground">You have no liked items.</p>}
                  </div>
                  <Link to="/cart"><Button className="w-full">View Cart & Liked</Button></Link>
                </div>
              </PopoverContent>
            </Popover>

            {user ? (
              <div className="hidden sm:flex items-center space-x-2">
                <span className="text-sm font-medium">Welcome, {user.username}</span>
                <Button variant="outline" size="sm" onClick={logout}><LogOut className="h-4 w-4 mr-2" />Logout</Button>
              </div>
            ) : (
              <Link to="/login" className="hidden sm:flex"><Button variant="outline" size="sm">Login</Button></Link>
            )}

            <Button variant="ghost" size="icon" className="md:hidden h-9 w-9" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>{mobileMenuOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}</Button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="md:hidden border-t glass-effect">
          <div className="px-4 py-2 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path} onClick={() => setMobileMenuOpen(false)} className={`flex items-center space-x-3 px-3 py-2 rounded-lg transition-all duration-200 ${isActive ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                  <Icon className="h-5 w-5" /><span className="font-medium">{item.label}</span>
                </Link>
              );
            })}
            {user ? (
              <Button variant="outline" className="w-full mt-2" onClick={() => { logout(); setMobileMenuOpen(false); }}><LogOut className="h-4 w-4 mr-2" />Logout</Button>
            ) : (
              <Link to="/login" className="w-full"><Button variant="outline" className="w-full mt-2" onClick={() => setMobileMenuOpen(false)}>Login</Button></Link>
            )}
          </div>
        </motion.div>
      )}
    </motion.nav>
  );
};

export default Navbar;
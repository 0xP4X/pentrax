import React from 'react';
import { Github, Twitter, Linkedin, Zap } from 'lucide-react';
import { Link } from 'react-router-dom';

const Footer = () => {
  const socialLinks = [
    { icon: Twitter, href: '#' },
    { icon: Github, href: '#' },
    { icon: Linkedin, href: '#' },
  ];

  const footerLinks = [
    { title: 'Platform', links: ['Dashboard', 'Labs', 'Marketplace', 'Community'] },
    { title: 'Resources', links: ['Documentation', 'Blog', 'Support', 'API Status'] },
    { title: 'Company', links: ['About Us', 'Careers', 'Press', 'Contact'] },
  ];

  return (
    <footer className="bg-muted/30 mt-16">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          <div className="space-y-8 xl:col-span-1">
            <Link to="/" className="flex items-center space-x-2">
              <Zap className="h-8 w-8 text-green-400" />
              <span className="text-xl font-bold bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">PentraX</span>
            </Link>
            <p className="text-muted-foreground text-base">
              The ultimate cybersecurity collaboration hub.
            </p>
            <div className="flex space-x-6">
              {socialLinks.map((social, index) => (
                <a key={index} href={social.href} className="text-muted-foreground hover:text-foreground">
                  <social.icon className="h-6 w-6" />
                </a>
              ))}
            </div>
          </div>
          <div className="mt-12 grid grid-cols-2 gap-8 xl:mt-0 xl:col-span-2">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <p className="font-semibold text-foreground">Platform</p>
                <ul className="mt-4 space-y-4">
                  <li><Link to="/labs" className="text-base text-muted-foreground hover:text-foreground">Labs</Link></li>
                  <li><Link to="/marketplace" className="text-base text-muted-foreground hover:text-foreground">Marketplace</Link></li>
                  <li><Link to="/community" className="text-base text-muted-foreground hover:text-foreground">Community</Link></li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <p className="font-semibold text-foreground">Resources</p>
                <ul className="mt-4 space-y-4">
                  <li><Link to="/documentation" className="text-base text-muted-foreground hover:text-foreground">Docs</Link></li>
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">API Status</Link></li>
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">Support</Link></li>
                </ul>
              </div>
            </div>
            <div className="md:grid md:grid-cols-2 md:gap-8">
              <div>
                <p className="font-semibold text-foreground">Company</p>
                <ul className="mt-4 space-y-4">
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">About</Link></li>
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">Blog</Link></li>
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">Careers</Link></li>
                </ul>
              </div>
              <div className="mt-12 md:mt-0">
                <p className="font-semibold text-foreground">Legal</p>
                <ul className="mt-4 space-y-4">
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">Privacy</Link></li>
                  <li><Link to="#" className="text-base text-muted-foreground hover:text-foreground">Terms</Link></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-12 border-t border-border pt-8">
          <p className="text-base text-muted-foreground xl:text-center">
            &copy; {new Date().getFullYear()} PentraX. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

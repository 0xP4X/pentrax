export const discussions = [
    {
      id: 1,
      title: 'Best practices for SQL injection testing in 2024',
      content: 'I\'m preparing for a new pentest engagement and I want to make sure my SQLi testing methodology is up to date. What are some of the go-to tools, techniques, and payloads you all are using these days? Any specific advice for bypassing modern WAFs?',
      author: 'CyberNinja',
      authorLevel: 'Expert',
      category: 'Web Security',
      replies: 2,
      likes: 2,
      views: 1247,
      timeAgo: '2 hours ago',
      isHot: true,
      tags: ['SQL Injection', 'Web Security', 'Testing'],
      comments: [
          { id: 101, author: 'SecurityGuru', text: 'Good question! I\'ve found that time-based blind SQLi is still very effective against many targets. Also, look into using tools like SQLmap with custom tamper scripts.'},
          { id: 102, author: 'WebDevWizard', text: 'From a dev perspective, parameterized queries are the key. Make sure your clients understand this!'},
      ],
      likedBy: ['SecurityGuru', 'PenTestPro'],
      savedBy: ['SecurityGuru']
    },
    {
      id: 2,
      title: 'New vulnerability discovered in popular IoT devices',
      content: 'Has anyone seen the latest CVE regarding the firmware on a popular smart plug? It looks like a classic buffer overflow. I\'m thinking of trying to build a PoC for it in one of the PentraX labs. Any collaborators interested?',
      author: 'SecurityResearcher',
      authorLevel: 'Professional',
      category: 'IoT Security',
      replies: 1,
      likes: 67,
      views: 2156,
      timeAgo: '4 hours ago',
      isHot: true,
      tags: ['IoT', 'Vulnerability', 'Research'],
      comments: [
          {id: 201, author: 'BugHunter', text: 'I am! Sent you a DM. Let\'s connect.'}
      ],
      likedBy: [],
      savedBy: []
    },
    {
      id: 3,
      title: 'Building a custom OSINT framework - Need feedback',
      content: 'I\'ve been working on a Python-based OSINT framework that automates a lot of the initial information gathering steps. It integrates with a few APIs. Before I release it on the marketplace, I\'d love to get some feedback from the community.',
      author: 'IntelGatherer',
      authorLevel: 'Advanced',
      category: 'OSINT',
      replies: 0,
      likes: 34,
      views: 892,
      timeAgo: '6 hours ago',
      isHot: false,
      tags: ['OSINT', 'Framework', 'Development'],
      comments: [],
      likedBy: [],
      savedBy: []
    },
    {
      id: 4,
      title: 'Ethical hacking certification path recommendations',
      content: 'I\'m relatively new to the field and looking to get certified. There are so many options (OSCP, eJPT, PNPT, etc.). For those of you who are experienced, what path would you recommend for someone looking to get into pentesting?',
      author: 'EthicalHacker101',
      authorLevel: 'Intermediate',
      category: 'Career',
      replies: 0,
      likes: 89,
      views: 3421,
      timeAgo: '8 hours ago',
      isHot: false,
      tags: ['Certification', 'Career', 'Learning'],
      comments: [],
      likedBy: [],
      savedBy: []
    },
    {
      id: 5,
      title: 'Advanced network pivoting techniques',
      content: 'Let\'s talk about pivoting. Once you get a foothold in a network, what are your favorite tools and techniques for moving laterally? I\'m a big fan of using SSH tunneling, but I\'m curious what other creative methods people are using.',
      author: 'NetworkNinja',
      authorLevel: 'Expert',
      category: 'Network Security',
      replies: 0,
      likes: 52,
      views: 1567,
      timeAgo: '12 hours ago',
      isHot: false,
      tags: ['Network', 'Pivoting', 'Advanced'],
      comments: [],
      likedBy: [],
      savedBy: []
    }
  ];

export const leaderboard = [
    { rank: 1, name: 'CyberNinja', points: 15420, badge: 'Legend', contributions: 234 },
    { rank: 2, name: 'SecurityGuru', points: 12890, badge: 'Expert', contributions: 189 },
    { rank: 3, name: 'EthicalHacker', points: 11567, badge: 'Expert', contributions: 156 },
    { rank: 4, name: 'PenTestPro', points: 9834, badge: 'Professional', contributions: 134 },
    { rank: 5, name: 'BugHunter', points: 8921, badge: 'Professional', contributions: 112 },
  ];

export const events = [
    {
      id: 1,
      title: 'Weekly CTF Challenge',
      type: 'Competition',
      date: 'Every Friday',
      participants: 156,
      description: 'Test your skills in our weekly capture the flag competition'
    },
    {
      id: 2,
      title: 'Web Security Workshop',
      type: 'Workshop',
      date: 'June 28, 2025',
      participants: 89,
      description: 'Advanced web application security testing techniques'
    },
    {
      id: 3,
      title: 'Bug Bounty Bootcamp',
      type: 'Training',
      date: 'July 5, 2025',
      participants: 234,
      description: 'Learn professional bug bounty hunting methodologies'
    }
  ];
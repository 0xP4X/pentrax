import { Target, Globe, Wifi, Code, Database, Eye } from 'lucide-react';

export const labs = [
    {
      id: 1,
      name: 'SQL Injection Mastery',
      description: 'Learn advanced SQL injection techniques and defense mechanisms. Your goal is to bypass the login and find the admin flag.',
      category: 'Web Exploitation',
      difficulty: 'Advanced',
      duration: '45 min',
      participants: 1247,
      rating: 4.8,
      tags: ['SQL', 'Database', 'Web Security'],
      isNew: true,
      target: 'vulnerable-webapp.local',
      objectives: [
        'Bypass the login form using SQL injection.',
        'Find the administrator\'s credentials.',
        'Access the admin panel and retrieve the flag.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'notes.txt': {
              type: 'file',
              content: 'The target is vulnerable-webapp.local. The login form seems to be the main entry point. I should try some common SQLi payloads.'
            },
            'tools': { type: 'dir', content: {} }
          }
        }
      }
    },
    {
      id: 2,
      name: 'Network Reconnaissance',
      description: 'Master network scanning and enumeration techniques. Your goal is to map the network and find a hidden service.',
      category: 'Network Security',
      difficulty: 'Intermediate',
      duration: '30 min',
      participants: 892,
      rating: 4.6,
      tags: ['Nmap', 'Scanning', 'Enumeration'],
      isNew: false,
      target: '10.10.10.0/24',
      objectives: [
        'Scan the target network range.',
        'Identify all active hosts.',
        'Find a web server running on a non-standard port.',
        'Locate the flag on the hidden web page.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'scan_results': { type: 'dir', content: {} },
            'instructions.txt': {
              type: 'file',
              content: 'Use nmap to scan the 10.10.10.0/24 range. Look for open ports and services. There might be something interesting on an unusual port.'
            }
          }
        }
      }
    },
    {
      id: 3,
      name: 'Buffer Overflow Basics',
      description: 'Introduction to buffer overflow vulnerabilities and exploitation. Your goal is to crash the application and gain control.',
      category: 'Binary Exploitation',
      difficulty: 'Beginner',
      duration: '60 min',
      participants: 654,
      rating: 4.7,
      tags: ['Buffer Overflow', 'Assembly', 'Exploitation'],
      isNew: false,
      target: 'vuln-app',
      objectives: [
        'Analyze the provided vulnerable application.',
        'Craft an input that causes a buffer overflow.',
        'Overwrite the return address to execute custom code.',
        'Read the content of flag.txt.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'vuln-app': { type: 'file', content: 'ELF 64-bit LSB executable...' },
            'source.c': {
              type: 'file',
              content: '#include <stdio.h>\n#include <string.h>\n\nvoid greet(char *name) {\n  char buffer[64];\n  strcpy(buffer, name);\n  printf("Hello, %s!\\n", buffer);\n}\n\nint main(int argc, char **argv) {\n  if (argc > 1) {\n    greet(argv[1]);\n  }\n  return 0;\n}'
            },
            'flag.txt': {
              type: 'file',
              content: 'pntx{bUFF3r_0v3rfl0w_sUcc3ss!}'
            }
          }
        }
      }
    },
    {
      id: 4,
      name: 'OSINT Investigation',
      description: 'Open source intelligence gathering and analysis techniques. Find information about the target company.',
      category: 'OSINT',
      difficulty: 'Intermediate',
      duration: '40 min',
      participants: 543,
      rating: 4.5,
      tags: ['OSINT', 'Investigation', 'Social Engineering'],
      isNew: true,
      target: 'SecureCorp',
      objectives: [
        'Find the email format for SecureCorp employees.',
        'Identify the CEO of the company.',
        'Discover a leaked password associated with a company email.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'case-file.txt': {
              type: 'file',
              content: 'Target: SecureCorp. Your mission is to gather as much public information as possible. Use search engines, social media, and breach databases.'
            }
          }
        }
      }
    },
    {
      id: 5,
      name: 'XSS Attack Vectors',
      description: 'Comprehensive guide to Cross-Site Scripting vulnerabilities. Exploit a stored XSS to steal admin cookies.',
      category: 'Web Exploitation',
      difficulty: 'Intermediate',
      duration: '35 min',
      participants: 789,
      rating: 4.6,
      tags: ['XSS', 'JavaScript', 'Web Security'],
      isNew: false,
      target: 'blog.pentrax.local',
      objectives: [
        'Find a stored XSS vulnerability in the blog comments.',
        'Craft a payload to steal session cookies.',
        'Capture the admin\'s cookie and gain access.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'notes.txt': {
              type: 'file',
              content: 'The target blog has a comment section. It seems to sanitize some input, but maybe not all. I should try different XSS payloads.'
            }
          }
        }
      }
    },
    {
      id: 6,
      name: 'Wireless Network Hacking',
      description: 'Learn to assess and exploit wireless network vulnerabilities. Crack the WPA2 password.',
      category: 'Network Security',
      difficulty: 'Advanced',
      duration: '50 min',
      participants: 432,
      rating: 4.9,
      tags: ['WiFi', 'WPA', 'Wireless Security'],
      isNew: true,
      target: 'PentraX-Guest-WiFi',
      objectives: [
        'Capture the WPA2 handshake.',
        'Use a wordlist to crack the password.',
        'Connect to the network and find the flag on the router admin page.',
      ],
      filesystem: {
        '~': {
          type: 'dir',
          content: {
            'wordlists': { type: 'dir', content: { 'rockyou.txt': { type: 'file', content: '...' } } },
            'handshake.cap': { type: 'file', content: '...' }
          }
        }
      }
    }
  ];

export const categories = [
    { name: 'All', icon: Target, count: labs.length },
    { name: 'Web Exploitation', icon: Globe, count: labs.filter(l => l.category === 'Web Exploitation').length },
    { name: 'Network Security', icon: Wifi, count: labs.filter(l => l.category === 'Network Security').length },
    { name: 'Binary Exploitation', icon: Code, count: labs.filter(l => l.category === 'Binary Exploitation').length },
    { name: 'Database Security', icon: Database, count: labs.filter(l => l.category === 'Database Security').length },
    { name: 'OSINT', icon: Eye, count: labs.filter(l => l.category === 'OSINT').length },
  ];
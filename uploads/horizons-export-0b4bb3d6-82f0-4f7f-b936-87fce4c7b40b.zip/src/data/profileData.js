import { Target, Star, TrendingUp, Clock, Shield, Code, User } from 'lucide-react';

export const userStats = [
    { label: 'Labs Completed', value: '47', icon: Target, color: 'text-green-400' },
    { label: 'Total Score', value: '12,847', icon: Star, color: 'text-yellow-400' },
    { label: 'Rank', value: '#156', icon: TrendingUp, color: 'text-blue-400' },
    { label: 'Streak', value: '23 days', icon: Clock, color: 'text-purple-400' },
  ];

export const achievements = [
    { name: 'First Blood', description: 'Complete your first lab', icon: Target, earned: true },
    { name: 'Web Warrior', description: 'Complete 10 web security labs', icon: Shield, earned: true },
    { name: 'Code Breaker', description: 'Solve 5 cryptography challenges', icon: Code, earned: true },
    { name: 'Network Ninja', description: 'Master network security labs', icon: Shield, earned: false },
    { name: 'OSINT Expert', description: 'Complete advanced OSINT challenges', icon: Target, earned: false },
    { name: 'Bug Hunter', description: 'Find 50 vulnerabilities', icon: Target, earned: false },
  ];

export const recentActivity = [
    { type: 'lab', title: 'Completed SQL Injection Mastery', time: '2 hours ago', points: 150 },
    { type: 'achievement', title: 'Earned "Web Warrior" badge', time: '1 day ago', points: 500 },
    { type: 'discussion', title: 'Posted in "Best OSINT Tools"', time: '2 days ago', points: 25 },
    { type: 'lab', title: 'Completed Buffer Overflow Basics', time: '3 days ago', points: 200 },
    { type: 'marketplace', title: 'Purchased Advanced Scanner Pro', time: '5 days ago', points: 0 },
  ];

export const skills = [
    { name: 'Web Security', level: 85, category: 'Expert' },
    { name: 'Network Security', level: 72, category: 'Advanced' },
    { name: 'Binary Exploitation', level: 45, category: 'Intermediate' },
    { name: 'OSINT', level: 68, category: 'Advanced' },
    { name: 'Cryptography', level: 55, category: 'Intermediate' },
    { name: 'Forensics', level: 38, category: 'Beginner' },
  ];
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import Navbar from '@/components/Navbar';
import Dashboard from '@/pages/Dashboard';
import Labs from '@/pages/Labs';
import Marketplace from '@/pages/Marketplace';
import Community from '@/pages/Community';
import Profile from '@/pages/Profile';
import Terminal from '@/pages/Terminal';
import Login from '@/pages/Login';
import LabDetail from '@/pages/LabDetail';
import Settings from '@/pages/Settings';
import Documentation from '@/pages/Documentation';
import Onboarding from '@/pages/Onboarding';
import AdminDashboard from '@/pages/AdminDashboard';
import Cart from '@/pages/Cart';
import DiscussionDetail from '@/pages/DiscussionDetail';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useAuth } from '@/contexts/AuthContext';
import SplashScreen from '@/components/SplashScreen';
import Footer from '@/components/Footer';

function App() {
  const [darkMode, setDarkMode] = useState(true);
  const { user } = useAuth();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const savedTheme = localStorage.getItem('pentrax-theme');
    if (savedTheme) {
      setDarkMode(savedTheme === 'dark');
    }
    setTimeout(() => setIsLoading(false), 2500);
  }, []);

  useEffect(() => {
    localStorage.setItem('pentrax-theme', darkMode ? 'dark' : 'light');
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <Router>
      <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
        <Helmet>
          <title>PentraX - Cybersecurity & Ethical Hacking Hub</title>
          <meta name="description" content="Professional cybersecurity collaboration platform for ethical hackers, penetration testers, and security researchers. Practice, collaborate, and commercialize cybersecurity knowledge." />
        </Helmet>
        
        <AnimatePresence>
          {isLoading && <SplashScreen />}
        </AnimatePresence>
        
        {!isLoading && (
          <div className="bg-background text-foreground min-h-screen flex flex-col">
            <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />
            
            <motion.main
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="pt-16 flex-grow"
            >
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/login" element={<Login />} />
                <Route path="/onboarding" element={<Onboarding />} />
                <Route path="/labs" element={<Labs />} />
                <Route path="/labs/:labId" element={<LabDetail />} />
                <Route path="/marketplace" element={<Marketplace />} />
                <Route path="/community" element={<Community />} />
                <Route path="/community/discussion/:discussionId" element={<DiscussionDetail />} />
                <Route path="/documentation" element={<Documentation />} />

                <Route element={<ProtectedRoute />}>
                  <Route path="/profile" element={<Profile />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="/terminal/:labId" element={<Terminal />} />
                  <Route path="/cart" element={<Cart />} />
                  <Route path="/admin" element={user?.isAdmin ? <AdminDashboard /> : <Navigate to="/" />} />
                </Route>
              </Routes>
            </motion.main>
            
            <Footer />
            <Toaster />
          </div>
        )}
      </div>
    </Router>
  );
}

export default App;

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { 
  Users, 
  MessageSquare, 
  Clock, 
  Plus,
  Search,
  ThumbsUp,
  MessageCircle as MessageCircleIcon,
  Share2,
  Bookmark,
  Award,
  Shield,
  Zap,
  Target
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogDescription, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useCommunity } from '@/contexts/CommunityContext';
import { leaderboard, events } from '@/data/communityData';

const getBadgeColor = (badge) => {
  switch (badge) {
    case 'Legend': return 'text-purple-400';
    case 'Expert': return 'text-orange-400';
    case 'Professional': return 'text-blue-400';
    case 'Advanced': return 'text-green-400';
    case 'Intermediate': return 'text-yellow-400';
    default: return 'text-gray-400';
  }
};

const getBadgeIcon = (badge) => {
  switch (badge) {
    case 'Legend': return Award;
    case 'Expert': return Shield;
    case 'Professional': return Zap;
    default: return Target;
  }
};

const Community = () => {
  const [activeTab, setActiveTab] = useState('discussions');
  const [searchTerm, setSearchTerm] = useState('');
  const [newDiscussionTitle, setNewDiscussionTitle] = useState('');
  const [newDiscussionContent, setNewDiscussionContent] = useState('');
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { discussions, addDiscussion, toggleLike, isLiked, toggleSave, isSaved } = useCommunity();

  const handleProtectedAction = (action) => {
    if (!user) {
      toast({
        title: 'Login Required',
        description: 'Please log in to interact with the community.',
        variant: 'destructive',
      });
      navigate('/login');
      return;
    }
    action();
  };
  
  const handleShare = () => {
    toast({
      title: "Link Copied!",
      description: "Discussion link copied to clipboard (simulated)."
    });
  }

  const handlePostDiscussion = () => {
    if (newDiscussionTitle.trim() && newDiscussionContent.trim()) {
      handleProtectedAction(() => {
        addDiscussion(newDiscussionTitle, newDiscussionContent);
        setNewDiscussionTitle('');
        setNewDiscussionContent('');
        toast({
          title: "Discussion Posted!",
          description: "Your new discussion is now live.",
        });
      });
    }
  };
  
  const filteredDiscussions = discussions.filter(d => 
    d.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    (d.content && d.content.toLowerCase().includes(searchTerm.toLowerCase())) ||
    d.tags.some(t => t.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Security <span className="text-purple-400">Community</span></h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">Connect, collaborate, and learn with cybersecurity professionals worldwide</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="glass-effect rounded-xl p-2 mb-8">
          <div className="flex flex-wrap space-x-1">
            {[{ id: 'discussions', label: 'Discussions', icon: MessageSquare }, { id: 'leaderboard', label: 'Leaderboard', icon: Award }, { id: 'events', label: 'Events', icon: Clock }].map(tab => {
              const Icon = tab.icon;
              return <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center space-x-2 px-3 py-2 sm:px-4 rounded-lg transition-all duration-200 text-sm sm:text-base ${activeTab === tab.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}><Icon className="h-4 w-4" /><span>{tab.label}</span></button>;
            })}
          </div>
        </motion.div>
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-3">
            {activeTab === 'discussions' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="relative flex-1"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" /><input type="text" placeholder="Search discussions..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" /></div>
                  <Dialog><DialogTrigger asChild><Button onClick={() => handleProtectedAction(() => {})}> <Plus className="mr-2 h-4 w-4" />New Discussion</Button></DialogTrigger>
                    <DialogContent>
                      <DialogHeader><DialogTitle>Start a New Discussion</DialogTitle><DialogDescription>Share your thoughts with the community.</DialogDescription></DialogHeader>
                      <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4"><Label htmlFor="title" className="text-right">Title</Label><Input id="title" placeholder="e.g., Best practices for..." className="col-span-3" value={newDiscussionTitle} onChange={(e) => setNewDiscussionTitle(e.target.value)} /></div>
                        <div className="grid grid-cols-4 items-start gap-4"><Label htmlFor="content" className="text-right mt-2">Content</Label><Textarea id="content" placeholder="Your thoughts..." className="col-span-3" value={newDiscussionContent} onChange={(e) => setNewDiscussionContent(e.target.value)} /></div>
                      </div>
                      <DialogFooter><DialogClose asChild><Button onClick={handlePostDiscussion}>Post Discussion</Button></DialogClose></DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
                <div className="space-y-4">
                  {filteredDiscussions.map((discussion, index) => (
                    <motion.div key={discussion.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="glass-effect rounded-xl p-4 md:p-6 hover:scale-[1.02] transition-all duration-200">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center space-x-2">{discussion.isHot && <span className="px-2 py-1 bg-red-500 text-white text-xs rounded-full">HOT</span>}<span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md">{discussion.category}</span></div>
                        <div className="text-xs sm:text-sm text-muted-foreground">{discussion.timeAgo}</div>
                      </div>
                      <Link to={`/community/discussion/${discussion.id}`}><h3 className="text-lg font-semibold mb-2 hover:text-primary transition-colors">{discussion.title}</h3></Link>
                      <div className="flex items-center space-x-4 mb-3">
                        <div className="flex items-center space-x-2"><div className="w-6 h-6 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full"></div><span className="text-sm font-medium">{discussion.author}</span><span className={`text-xs ${getBadgeColor(discussion.authorLevel)}`}>{discussion.authorLevel}</span></div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 sm:space-x-4 text-sm text-muted-foreground">
                          <Button variant="ghost" size="sm" onClick={() => handleProtectedAction(() => toggleLike(discussion.id))}><ThumbsUp className={`mr-1 sm:mr-2 h-4 w-4 ${isLiked(discussion.id) ? 'fill-blue-500 text-blue-500' : ''}`} /><span>{discussion.likes}</span></Button>
                          <Link to={`/community/discussion/${discussion.id}`} className="flex items-center p-2 rounded-md hover:bg-accent"><MessageCircleIcon className="mr-1 sm:mr-2 h-4 w-4" /><span>{discussion.replies}</span></Link>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" onClick={() => handleProtectedAction(() => toggleSave(discussion.id))}><Bookmark className={`h-4 w-4 ${isSaved(discussion.id) ? 'fill-yellow-400 text-yellow-500' : ''}`} /></Button>
                          <Button size="sm" variant="outline" onClick={handleShare}><Share2 className="h-4 w-4" /></Button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
            {activeTab === 'leaderboard' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="space-y-4">
                {leaderboard.map((user, index) => {
                  const BadgeIcon = getBadgeIcon(user.badge);
                  return (
                    <motion.div key={user.rank} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="glass-effect rounded-xl p-4 md:p-6 hover:scale-[1.02] transition-all duration-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 md:space-x-4">
                          <div className={`text-lg md:text-2xl font-bold ${user.rank === 1 ? 'text-yellow-400' : user.rank === 2 ? 'text-gray-400' : user.rank === 3 ? 'text-orange-400' : 'text-muted-foreground'}`}>#{user.rank}</div>
                          <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full"></div>
                          <div><div className="font-semibold text-sm md:text-base">{user.name}</div><div className="flex items-center space-x-2"><BadgeIcon className={`h-4 w-4 ${getBadgeColor(user.badge)}`} /><span className={`text-xs md:text-sm ${getBadgeColor(user.badge)}`}>{user.badge}</span></div></div>
                        </div>
                        <div className="text-right"><div className="text-base md:text-xl font-bold text-green-400">{user.points.toLocaleString()}</div><div className="text-xs md:text-sm text-muted-foreground">{user.contributions} contributions</div></div>
                      </div>
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
            {activeTab === 'events' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="space-y-6">
                {events.map((event, index) => (
                  <motion.div key={event.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="glass-effect rounded-xl p-6 hover:scale-[1.02] transition-all duration-200 cursor-pointer">
                    <div className="flex flex-col sm:flex-row items-start justify-between">
                      <div className="mb-4 sm:mb-0">
                        <h3 className="text-xl font-semibold mb-2">{event.title}</h3><p className="text-muted-foreground mb-3">{event.description}</p>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm"><span className="px-2 py-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 rounded-md">{event.type}</span><div className="flex items-center space-x-1"><Clock className="h-4 w-4" /><span>{event.date}</span></div><div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>{event.participants} participants</span></div></div>
                      </div><Button onClick={() => handleProtectedAction(() => {})} className="w-full sm:w-auto">Join Event</Button>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </div>
          <div className="hidden lg:block space-y-6">
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.4 }} className="glass-effect rounded-xl p-6">
              <h3 className="font-semibold mb-4">Trending Topics</h3><div className="space-y-2">{['Zero-day exploits', 'AI in cybersecurity', 'Cloud security', 'Bug bounty tips', 'OSINT techniques'].map(topic => (<div key={topic} className="text-sm text-muted-foreground hover:text-foreground cursor-pointer">#{topic}</div>))}</div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Community;

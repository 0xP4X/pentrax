import React from 'react';
import { motion } from 'framer-motion';
import { User, Bell, Shield, Code } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const Settings = () => {
  const { toast } = useToast();

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your changes have been saved successfully.",
    });
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Settings
          </h1>
          <p className="text-xl text-muted-foreground">
            Manage your account and platform preferences.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-8"
        >
          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <User className="mr-3 h-6 w-6 text-primary" />
              Profile Settings
            </h2>
            <p className="text-muted-foreground">This feature is under development.</p>
          </div>

          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Bell className="mr-3 h-6 w-6 text-primary" />
              Notifications
            </h2>
            <p className="text-muted-foreground">This feature is under development.</p>
          </div>

          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Shield className="mr-3 h-6 w-6 text-primary" />
              Security
            </h2>
            <p className="text-muted-foreground">This feature is under development.</p>
          </div>

          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Code className="mr-3 h-6 w-6 text-primary" />
              API Access
            </h2>
            <p className="text-muted-foreground">This feature is under development.</p>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleSave}>Save Changes</Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Settings;
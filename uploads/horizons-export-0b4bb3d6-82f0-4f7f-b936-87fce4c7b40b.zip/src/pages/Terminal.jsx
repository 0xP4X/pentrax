import React, { useState, useEffect, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Terminal as TerminalIcon, 
  Play, 
  Square, 
  RotateCcw, 
  Maximize2,
  Minimize2,
  CheckCircle,
  Lightbulb
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { labs } from '@/data/labsData';
import { cloneDeep } from 'lodash';
import { usePoints } from '@/contexts/PointsContext';

const Terminal = () => {
  const { labId } = useParams();
  const { addPoints } = usePoints();
  const [isRunning, setIsRunning] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentPath, setCurrentPath] = useState(['~']);
  const [labFilesystem, setLabFilesystem] = useState({});
  const [completedObjectives, setCompletedObjectives] = useState([]);
  const terminalRef = useRef(null);
  const inputRef = useRef(null);
  const { toast } = useToast();

  const lab = labs.find(l => l.id.toString() === labId) || {
    id: 'practice',
    name: 'Practice Environment',
    target: 'sandbox.local',
    objectives: ['Explore the terminal. Try commands like `ls`, `cat welcome.txt`, `help`.'],
    filesystem: { '~': { type: 'dir', content: { 'welcome.txt': { type: 'file', content: 'Welcome to the practice terminal!' } } } }
  };

  useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, [isRunning]);

  useEffect(() => {
    if (terminalRef.current) terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
  }, [terminalOutput]);

  const handleStartLab = () => {
    setIsRunning(true);
    setLabFilesystem(cloneDeep(lab.filesystem));
    setCompletedObjectives([]);
    setTerminalOutput([
      { type: 'system', content: `Starting container for lab: ${lab.name}...` },
      { type: 'system', content: 'Container started successfully!' },
      { type: 'system', content: 'Welcome to PentraX Lab Environment. Type "help" for commands.' },
    ]);
    setCurrentPath(['~']);
  };

  const handleStopLab = () => {
    setIsRunning(false);
    setTerminalOutput([]);
    setCurrentInput('');
  };

  const handleReset = () => {
    handleStopLab();
    setTimeout(handleStartLab, 100);
  };

  const getPathObject = (pathArray, fs) => {
    let current = fs;
    for (const part of pathArray) {
      if (current && current.type === 'dir' && current.content[part]) {
        current = current.content[part];
      } else {
        return null;
      }
    }
    return current;
  };

  const processCommand = (command) => {
    const args = command.split(' ').filter(Boolean);
    const cmd = args[0]?.toLowerCase();
    let newOutput = [];

    if (!cmd) return;

    newOutput.push({ type: 'input', content: `pentrax@ubuntu:${currentPath.join('/')}$ ${command}` });

    switch (cmd) {
      case 'help':
        newOutput.push({ type: 'output', content: 'Available commands: ls, cd, cat, pwd, clear, help, whoami, nmap, gobuster, sqlmap' });
        break;
      case 'whoami':
        newOutput.push({ type: 'output', content: 'pentrax' });
        break;
      case 'pwd':
        newOutput.push({ type: 'output', content: `/home/pentrax/${currentPath.slice(1).join('/')}` });
        break;
      case 'clear':
        setTerminalOutput([]);
        return;
      case 'ls':
        const currentDir = getPathObject(currentPath, labFilesystem);
        if (currentDir && currentDir.type === 'dir') {
          const contentList = Object.entries(currentDir.content).map(([name, item]) => item.type === 'dir' ? `${name}/` : name).join('  ');
          newOutput.push({ type: 'output', content: contentList || '' });
        } else {
          newOutput.push({ type: 'output', content: 'ls: cannot access '.concat(currentPath.join('/')) });
        }
        break;
      case 'cd':
        const targetPath = args[1] || '~';
        if (targetPath === '..') {
          if (currentPath.length > 1) setCurrentPath(prev => prev.slice(0, -1));
        } else if (targetPath === '~' || targetPath === '/') {
          setCurrentPath(['~']);
        } else {
          const currentDir = getPathObject(currentPath, labFilesystem);
          if (currentDir?.content?.[targetPath]?.type === 'dir') {
            setCurrentPath(prev => [...prev, targetPath]);
          } else {
            newOutput.push({ type: 'output', content: `cd: no such file or directory: ${targetPath}` });
          }
        }
        break;
      case 'cat':
        const fileName = args[1];
        if (!fileName) {
          newOutput.push({ type: 'output', content: 'cat: missing file operand' });
        } else {
          const currentDir = getPathObject(currentPath, labFilesystem);
          const file = currentDir?.content?.[fileName];
          if (file && file.type === 'file') {
            newOutput.push({ type: 'output', content: file.content });
            if (fileName === 'flag.txt' && !completedObjectives.includes('flag')) {
              newOutput.push({ type: 'system', content: 'Congratulations! You found the flag and completed the lab!', icon: CheckCircle });
              toast({ title: "Lab Completed!", description: `You have successfully completed ${lab.name}.`, variant: "default", className: "bg-green-500 text-white border-green-500" });
              addPoints(100, `Completed lab: ${lab.name}`);
              setCompletedObjectives(prev => [...prev, 'flag']);
            }
          } else {
            newOutput.push({ type: 'output', content: `cat: ${fileName}: No such file or directory` });
          }
        }
        break;
      case 'nmap':
      case 'gobuster':
      case 'sqlmap':
        newOutput.push({ type: 'system', content: `Simulating ${cmd}... For a real experience, these tools would run in a backend container.`, icon: Lightbulb });
        newOutput.push({ type: 'output', content: `Running ${command}...\n...simulation complete.` });
        break;
      default:
        newOutput.push({ type: 'output', content: `bash: ${cmd}: command not found` });
    }
    setTerminalOutput(prev => [...prev, ...newOutput]);
  };

  const handleCommand = (e) => {
    if (e.key === 'Enter') {
      processCommand(currentInput);
      setCurrentInput('');
    }
  };

  return (
    <div className={`bg-background transition-all duration-300 ${isFullscreen ? 'fixed inset-0 z-[60]' : 'min-h-screen py-8 px-4'}`}>
      <div className={`mx-auto flex flex-col gap-4 ${isFullscreen ? 'h-full' : 'max-w-7xl'}`}>
        {!isFullscreen && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center">
            <h1 className="text-3xl sm:text-4xl font-bold mb-2"><span className="text-green-400">Terminal</span> Environment</h1>
            <p className="text-muted-foreground">Lab: {lab.name}</p>
          </motion.div>
        )}
        <div className={`grid gap-4 ${isFullscreen ? 'grid-cols-1 h-full' : 'lg:grid-cols-3'}`}>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className={`terminal-bg rounded-xl border border-green-400/30 overflow-hidden flex flex-col ${isFullscreen ? 'h-full' : 'h-[60vh] lg:h-[600px]'} lg:col-span-2`}>
            <div className="flex items-center justify-between p-2 md:p-4 border-b border-green-400/30 bg-black/50 flex-shrink-0">
              <div className="flex items-center space-x-3"><div className="flex space-x-2"><div className="w-3 h-3 rounded-full bg-red-500"></div><div className="w-3 h-3 rounded-full bg-yellow-500"></div><div className="w-3 h-3 rounded-full bg-green-500"></div></div><div className="flex items-center space-x-2 text-green-400"><TerminalIcon className="h-4 w-4" /><span className="font-mono text-xs sm:text-sm">{isRunning ? `pentrax@ubuntu: ${lab.name}` : 'Terminal (Stopped)'}</span></div></div>
              <div className="flex items-center space-x-1 sm:space-x-2">{!isRunning ? <Button size="sm" onClick={handleStartLab} className="bg-green-600 hover:bg-green-700 text-xs sm:text-sm"><Play className="h-4 w-4 mr-1" />Start</Button> : <Button size="sm" variant="destructive" onClick={handleStopLab} className="text-xs sm:text-sm"><Square className="h-4 w-4 mr-1" />Stop</Button>}<Button size="sm" variant="outline" onClick={handleReset} disabled={!isRunning}><RotateCcw className="h-4 w-4" /></Button><Button size="sm" variant="outline" onClick={() => setIsFullscreen(!isFullscreen)}>{isFullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}</Button></div>
            </div>
            <div className="flex-1 flex flex-col overflow-hidden" onClick={() => inputRef.current?.focus()}>
              {!isRunning ? (
                <div className="flex-1 flex items-center justify-center text-center p-8"><div><TerminalIcon className="h-16 w-16 text-green-400 mx-auto mb-4 opacity-50" /><h3 className="text-xl font-semibold text-green-400 mb-2">Terminal Ready</h3><p className="text-muted-foreground mb-6">Click "Start" to launch your Ubuntu environment.</p></div></div>
              ) : (
                <div ref={terminalRef} className="flex-1 p-4 font-mono text-sm text-green-400 overflow-y-auto scrollbar-hide">
                  {terminalOutput.map((line, index) => {
                    const Icon = line.icon;
                    return (<div key={index} className={`mb-1 flex items-start ${line.type === 'system' ? 'text-blue-400' : line.type === 'input' ? 'text-white' : 'text-green-300'}`}>{Icon && <Icon className="h-4 w-4 mr-2 mt-px flex-shrink-0" />}<div className="whitespace-pre-wrap break-words">{line.content}</div></div>);
                  })}
                  <div className="flex items-center text-green-400"><span>pentrax@ubuntu:{currentPath.join('/')}$ </span><input ref={inputRef} type="text" value={currentInput} onChange={(e) => setCurrentInput(e.target.value)} onKeyDown={handleCommand} className="flex-1 bg-transparent border-none outline-none text-white ml-1" autoComplete="off" autoCapitalize="off" autoCorrect="off" spellCheck="false" /><span className="animate-pulse">█</span></div>
                </div>
              )}
            </div>
          </motion.div>
          {!isFullscreen && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="glass-effect rounded-xl p-6 h-[60vh] lg:h-[600px] overflow-y-auto">
              <h2 className="text-2xl font-bold mb-6 flex items-center"><CheckCircle className="mr-3 h-6 w-6 text-green-400" />Objectives</h2>
              <ul className="space-y-4">
                {lab.objectives.map((objective, index) => (
                  <li key={index} className={`flex items-start transition-opacity ${completedObjectives.includes(objective) ? 'opacity-50' : ''}`}>
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0 ${completedObjectives.includes(objective) ? 'bg-green-500' : 'bg-primary'}`}>
                      {completedObjectives.includes(objective) ? <CheckCircle className="h-4 w-4 text-white" /> : <span className="text-primary-foreground font-bold text-sm">{index + 1}</span>}
                    </div>
                    <span className="text-muted-foreground">{objective}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Terminal;

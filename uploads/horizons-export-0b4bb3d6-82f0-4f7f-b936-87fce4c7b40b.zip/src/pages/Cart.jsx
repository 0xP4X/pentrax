import React from 'react';
import { motion } from 'framer-motion';
import { useCart } from '@/contexts/CartContext';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Heart, Trash2 } from 'lucide-react';

const Cart = () => {
  const { cartItems, likedItems } = useCart();

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            My Items
          </h1>
          <p className="text-xl text-muted-foreground">
            Review your cart and liked items before checkout.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="glass-effect rounded-xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <ShoppingCart className="mr-3 h-6 w-6 text-primary" />
              Shopping Cart ({cartItems.length})
            </h2>
            <div className="space-y-4">
              {cartItems.length > 0 ? (
                cartItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{item.name}</p>
                      <p className="text-sm text-green-400">${item.price}</p>
                    </div>
                    <Button variant="ghost" size="icon"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">Your cart is empty.</p>
              )}
            </div>
            {cartItems.length > 0 && (
              <Button className="w-full mt-6">Proceed to Checkout</Button>
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="glass-effect rounded-xl p-6"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <Heart className="mr-3 h-6 w-6 text-red-500" />
              Liked Items ({likedItems.length})
            </h2>
            <div className="space-y-4">
              {likedItems.length > 0 ? (
                likedItems.map(item => (
                  <div key={item.id} className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold">{item.name}</p>
                      <p className="text-sm text-muted-foreground">by {item.author}</p>
                    </div>
                    <Button variant="secondary">View Item</Button>
                  </div>
                ))
              ) : (
                <p className="text-muted-foreground">You haven't liked any items yet.</p>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
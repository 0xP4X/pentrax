import React from 'react';
import { motion } from 'framer-motion';
import { Users, Terminal, ShoppingBag, BarChart } from 'lucide-react';

const stats = [
  { name: 'Total Users', value: '15,234', icon: Users },
  { name: 'Active Labs', value: '1,289', icon: Terminal },
  { name: 'Tools in Marketplace', value: '1,847', icon: ShoppingBag },
  { name: 'Daily Activity', value: 'High', icon: BarChart },
];

const AdminDashboard = () => {
  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-12"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Admin <span className="text-red-500">Dashboard</span>
          </h1>
          <p className="text-xl text-muted-foreground">
            Platform overview and management tools.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
        >
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <div key={index} className="glass-effect rounded-xl p-6">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-muted-foreground">{stat.name}</p>
                  <Icon className="h-5 w-5 text-muted-foreground" />
                </div>
                <p className="text-3xl font-bold mt-2">{stat.value}</p>
              </div>
            );
          })}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="glass-effect rounded-xl p-6"
          >
            <h2 className="text-2xl font-bold mb-4">User Management</h2>
            <p className="text-muted-foreground">User management interface is under construction.</p>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="glass-effect rounded-xl p-6"
          >
            <h2 className="text-2xl font-bold mb-4">Content Moderation</h2>
            <p className="text-muted-foreground">Content moderation tools are under construction.</p>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
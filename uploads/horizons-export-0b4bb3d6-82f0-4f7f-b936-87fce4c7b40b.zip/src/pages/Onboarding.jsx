import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext';
import { Zap, Terminal, Users, ShoppingBag, ArrowRight, Check } from 'lucide-react';

const steps = [
  {
    icon: Zap,
    title: "Welcome to PentraX!",
    description: "Get ready to dive into the world of cybersecurity. Let's quickly walk you through what our platform offers.",
  },
  {
    icon: Terminal,
    title: "Hands-On Hacking Labs",
    description: "Jump into our realistic, sandboxed terminal environments to practice your skills on real-world targets. No setup required!",
  },
  {
    icon: ShoppingBag,
    title: "Cybersecurity Marketplace",
    description: "Discover, buy, and sell tools, scripts, and exploits. Find the perfect utility for your next engagement.",
  },
  {
    icon: Users,
    title: "Collaborate with the Community",
    description: "Join discussions, share knowledge, and team up with other cybersecurity professionals from around the globe.",
  },
  {
    icon: Check,
    title: "You're All Set!",
    description: "You're ready to start your journey. The dashboard is your mission control. Happy hacking!",
  },
];

const Onboarding = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const navigate = useNavigate();
  const { user, setIsNewUser } = useAuth();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setIsNewUser(false);
      navigate('/');
    }
  };

  const Icon = steps[currentStep].icon;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass-effect rounded-2xl p-8 text-center"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mx-auto mb-6 w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center">
              <Icon className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-2xl font-bold mb-2">
              {steps[currentStep].title.replace('!', `, ${user?.username}!`)}
            </h1>
            <p className="text-muted-foreground mb-8">
              {steps[currentStep].description}
            </p>
          </motion.div>
        </AnimatePresence>
        
        <div className="flex items-center justify-center space-x-2 mb-8">
          {steps.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full transition-all ${
                currentStep === index ? 'bg-primary scale-125' : 'bg-muted'
              }`}
            />
          ))}
        </div>

        <Button onClick={handleNext} size="lg" className="w-full cyber-glow">
          {currentStep === steps.length - 1 ? "Let's Go!" : "Continue"}
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </motion.div>
    </div>
  );
};

export default Onboarding;
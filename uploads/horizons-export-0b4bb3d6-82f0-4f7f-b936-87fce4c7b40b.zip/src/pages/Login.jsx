import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap } from 'lucide-react';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { login, isNewUser } = useAuth();

  const handleLogin = (e) => {
    e.preventDefault();
    if (username) {
      login(username);
      if (isNewUser) {
        navigate('/onboarding');
      } else {
        navigate('/');
      }
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Card className="w-full max-w-sm glass-effect">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4">
              <Zap className="h-12 w-12 text-green-400" />
            </div>
            <CardTitle className="text-2xl">Welcome to PentraX</CardTitle>
            <CardDescription>Enter your credentials to access the platform</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="e.g. CyberNinja or admin"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
              <Button type="submit" className="w-full cyber-glow">
                Login / Sign Up
              </Button>
            </form>
            <p className="text-center text-sm text-muted-foreground mt-4">
              This is a mock login. Any username/password will work. Use 'admin' for admin access.
            </p>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default Login;
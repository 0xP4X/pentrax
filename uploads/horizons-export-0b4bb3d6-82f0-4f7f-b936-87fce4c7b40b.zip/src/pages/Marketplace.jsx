import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Search, 
  Star, 
  Download, 
  DollarSign,
  Code,
  Users,
  ShoppingCart,
  Heart
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useCart } from '@/contexts/CartContext';
import { tools, categories } from '@/data/marketplaceData';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';

const ToolCard = ({ tool }) => {
  const { user } = useAuth();
  const { addToCart, toggleLike, isLiked } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleAction = (action) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to perform this action.",
        variant: "destructive"
      });
      navigate('/login');
      return;
    }
    action();
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="glass-effect rounded-xl p-6 flex flex-col hover:scale-105 transition-all duration-200 group"
    >
      <div className="flex-grow">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Code className="h-5 w-5 text-blue-400" />
            {tool.isPremium && <span className="px-2 py-1 bg-purple-500 text-white text-xs rounded-full">PRO</span>}
            {tool.isFeatured && <span className="px-2 py-1 bg-yellow-500 text-black text-xs rounded-full font-medium">FEATURED</span>}
          </div>
          <div className="flex items-center space-x-1"><Star className="h-4 w-4 text-yellow-400" /><span>{tool.rating}</span></div>
        </div>
        <h3 className="text-lg font-semibold mb-2 group-hover:text-primary transition-colors">{tool.name}</h3>
        <p className="text-sm text-muted-foreground mb-3">by {tool.author}</p>
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{tool.description}</p>
        <div className="flex flex-wrap gap-1 mb-4">{tool.tags.map(tag => <span key={tag} className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md">{tag}</span>)}</div>
      </div>
      <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
        <div className="flex items-center space-x-3">
          <div className="flex items-center space-x-1"><Download className="h-4 w-4" /><span>{tool.downloads.toLocaleString()}</span></div>
          <div className="flex items-center space-x-1"><Users className="h-4 w-4" /><span>{tool.lastUpdated}</span></div>
        </div>
      </div>
      <div className="flex items-center justify-between">
        <div className="text-xl font-bold text-green-400">{tool.price === 0 ? 'FREE' : `$${tool.price}`}</div>
        <div className="flex space-x-2">
          <Button size="sm" variant="outline" onClick={() => handleAction(() => toggleLike(tool))}>
            <Heart className={`h-4 w-4 ${isLiked(tool.id) ? 'fill-red-500 text-red-500' : ''}`} />
          </Button>
          <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={() => handleAction(() => addToCart(tool))}>
            <ShoppingCart className="mr-1 h-4 w-4" />{tool.price === 0 ? 'Get' : 'Buy'}
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

const Marketplace = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('Popular');

  const filteredTools = tools.filter(tool => {
    const matchesSearch = tool.name.toLowerCase().includes(searchTerm.toLowerCase()) || tool.description.toLowerCase().includes(searchTerm.toLowerCase()) || tool.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || tool.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const sortedTools = [...filteredTools].sort((a, b) => {
    switch (sortBy) {
      case 'Popular': return b.downloads - a.downloads;
      case 'Rating': return b.rating - a.rating;
      case 'Price (Low)': return a.price - b.price;
      case 'Price (High)': return b.price - a.price;
      default: return 0;
    }
  });

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Security <span className="text-blue-400">Marketplace</span></h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">Discover, purchase, and sell cybersecurity tools, scripts, and services from the community</p>
        </motion.div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="glass-effect rounded-xl p-6 mb-8">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="relative flex-1"><Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" /><input type="text" placeholder="Search tools, scripts, or services..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" /></div>
            <select value={selectedCategory} onChange={(e) => setSelectedCategory(e.target.value)} className="px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary">{categories.map(category => <option key={category.name} value={category.name}>{category.name} ({category.count})</option>)}</select>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="px-4 py-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"><option value="Popular">Most Popular</option><option value="Rating">Highest Rated</option><option value="Price (Low)">Price: Low to High</option><option value="Price (High)">Price: High to Low</option></select>
          </div>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">{sortedTools.map((tool) => <ToolCard key={tool.id} tool={tool} />)}</div>
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.5 }} className="mt-16 glass-effect rounded-xl p-8 text-center">
          <h2 className="text-3xl font-bold mb-4">Sell Your Security Tools</h2>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">Join our marketplace and monetize your cybersecurity expertise. Share your tools, scripts, and services with the community.</p>
          <Button size="lg" className="bg-green-600 hover:bg-green-700"><DollarSign className="mr-2 h-5 w-5" />Start Selling</Button>
        </motion.div>
      </div>
    </div>
  );
};

export default Marketplace;
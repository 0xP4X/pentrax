import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { labs } from '@/data/labsData';
import { Button } from '@/components/ui/button';
import { Play, Target, Clock, Star, CheckCircle } from 'lucide-react';

const LabDetail = () => {
  const { labId } = useParams();
  const lab = labs.find(l => l.id.toString() === labId);

  if (!lab) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <h1 className="text-2xl font-bold">Lab not found</h1>
      </div>
    );
  }

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Beginner': return 'text-green-400';
      case 'Intermediate': return 'text-yellow-400';
      case 'Advanced': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="flex justify-between items-start mb-4">
            <div>
              <span className={`font-bold ${getDifficultyColor(lab.difficulty)}`}>{lab.difficulty}</span>
              <h1 className="text-4xl md:text-5xl font-bold mt-2 mb-4">{lab.name}</h1>
            </div>
            <Link to={`/terminal/${lab.id}`}>
              <Button size="lg" className="cyber-glow">
                <Play className="mr-2 h-5 w-5" />
                Start Lab
              </Button>
            </Link>
          </div>

          <div className="flex items-center space-x-6 text-muted-foreground mb-8">
            <div className="flex items-center space-x-1">
              <Clock className="h-4 w-4" />
              <span>{lab.duration}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Star className="h-4 w-4 text-yellow-400" />
              <span>{lab.rating} / 5.0</span>
            </div>
            <div className="flex items-center space-x-1">
              <Target className="h-4 w-4" />
              <span>{lab.category}</span>
            </div>
          </div>

          <p className="text-lg text-muted-foreground mb-12">{lab.description}</p>

          <div className="glass-effect rounded-xl p-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center">
              <CheckCircle className="mr-3 h-6 w-6 text-green-400" />
              Objectives
            </h2>
            <ul className="space-y-4">
              {lab.objectives.map((objective, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
                  className="flex items-start"
                >
                  <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center mr-4 mt-1 flex-shrink-0">
                    <span className="text-primary-foreground font-bold text-sm">{index + 1}</span>
                  </div>
                  <span className="text-muted-foreground">{objective}</span>
                </motion.li>
              ))}
            </ul>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default LabDetail;
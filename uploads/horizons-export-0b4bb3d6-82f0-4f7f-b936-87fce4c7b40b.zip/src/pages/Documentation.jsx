import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Terminal, Shield } from 'lucide-react';

const Documentation = () => {
  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <FileText className="h-16 w-16 text-primary mx-auto mb-4" />
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            PentraX Documentation
          </h1>
          <p className="text-xl text-muted-foreground">
            Your guide to mastering the PentraX platform.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="space-y-8"
        >
          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Terminal className="mr-3 h-6 w-6 text-green-400" />
              Hacking Labs
            </h2>
            <p className="text-muted-foreground mb-4">
              Our labs provide a sandboxed Ubuntu environment accessible through your browser. Each lab comes with a specific set of objectives and pre-installed tools necessary to complete the challenge.
            </p>
            <ul className="list-disc list-inside space-y-2">
              <li>Start a lab from the Labs page.</li>
              <li>A terminal will open with a connection to a dedicated Docker container.</li>
              <li>Use standard Linux commands and the provided security tools to achieve the objectives.</li>
              <li>Find the 'flag.txt' file to complete the lab.</li>
            </ul>
          </div>

          <div className="glass-effect rounded-xl p-6">
            <h2 className="text-2xl font-bold mb-4 flex items-center">
              <Shield className="mr-3 h-6 w-6 text-blue-400" />
              Security & Sandboxing
            </h2>
            <p className="text-muted-foreground">
              Your security is our top priority. All lab environments are completely isolated from each other and from the main platform infrastructure. We use Docker containers to ensure that any activity within a lab is contained and cannot affect other users or systems.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Documentation;
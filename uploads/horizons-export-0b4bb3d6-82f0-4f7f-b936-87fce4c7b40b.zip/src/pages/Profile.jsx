import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  User, 
  Settings, 
  Award, 
  Target, 
  Clock, 
  TrendingUp,
  Shield,
  Code,
  Star,
  Calendar,
  MapPin,
  Link as LinkIcon,
  Edit,
  Save,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { userStats, achievements, recentActivity, skills } from '@/data/profileData';

const Profile = () => {
  const { user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const { toast } = useToast();

  const [profileData, setProfileData] = useState({
    username: user?.username || 'CyberNinja',
    location: 'San Francisco, CA',
    bio: 'Passionate cybersecurity professional specializing in web application security and penetration testing. Always learning and sharing knowledge with the community.',
    website: 'linkedin.com/in/cyberninja'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    setIsEditing(false);
    toast({
      title: "Profile Updated",
      description: "Your changes have been saved successfully.",
    });
  };

  const getActivityIcon = (type) => {
    switch (type) {
      case 'lab': return Target;
      case 'achievement': return Award;
      case 'discussion': return User;
      case 'marketplace': return Code;
      default: return Target;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center p-4">
        <h1 className="text-2xl font-bold mb-4">Access Denied</h1>
        <p className="text-muted-foreground mb-6">Please log in to view your profile.</p>
        <Link to="/login">
          <Button>Login</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="glass-effect rounded-xl p-8 mb-8">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
            <div className="flex items-center space-x-6 mb-6 md:mb-0">
              <div className="relative">
                <div className="w-24 h-24 bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 rounded-full flex items-center justify-center"><User className="h-12 w-12 text-white" /></div>
                <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center"><Shield className="h-4 w-4 text-white" /></div>
              </div>
              <div>
                {isEditing ? <Input name="username" value={profileData.username} onChange={handleInputChange} className="text-3xl font-bold mb-2" /> : <h1 className="text-3xl font-bold mb-2">{profileData.username}</h1>}
                <div className="flex items-center space-x-4 text-muted-foreground mb-2">
                  <div className="flex items-center space-x-1"><Award className="h-4 w-4 text-purple-400" /><span>Expert Level</span></div>
                  <div className="flex items-center space-x-1"><MapPin className="h-4 w-4" />{isEditing ? <Input name="location" value={profileData.location} onChange={handleInputChange} className="text-sm h-7" /> : <span>{profileData.location}</span>}</div>
                  <div className="flex items-center space-x-1"><Calendar className="h-4 w-4" /><span>Joined June 2025</span></div>
                </div>
                {isEditing ? <textarea name="bio" value={profileData.bio} onChange={handleInputChange} className="text-sm min-h-[80px] w-full rounded-md border border-input bg-background p-2" /> : <p className="text-muted-foreground max-w-md">{profileData.bio}</p>}
                <div className="flex items-center space-x-2 mt-3">
                  <LinkIcon className="h-4 w-4 text-blue-400" />
                  {isEditing ? <Input name="website" value={profileData.website} onChange={handleInputChange} className="text-sm h-7" /> : <a href="#" className="text-blue-400 hover:underline">{profileData.website}</a>}
                </div>
              </div>
            </div>
            <div className="flex space-x-2">
              {isEditing ? (
                <>
                  <Button onClick={handleSave}><Save className="mr-2 h-4 w-4" />Save</Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)}><X className="mr-2 h-4 w-4" />Cancel</Button>
                </>
              ) : (
                <Button variant="outline" onClick={() => setIsEditing(true)}><Edit className="mr-2 h-4 w-4" />Edit Profile</Button>
              )}
              <Link to="/settings"><Button variant="outline"><Settings className="mr-2 h-4 w-4" />Settings</Button></Link>
            </div>
          </div>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
          {userStats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div key={stat.label} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="glass-effect rounded-xl p-6 text-center hover:scale-105 transition-transform duration-200">
                <Icon className={`h-8 w-8 mx-auto mb-3 ${stat.color}`} />
                <div className="text-2xl font-bold mb-1">{stat.value}</div>
                <div className="text-sm text-muted-foreground">{stat.label}</div>
              </motion.div>
            );
          })}
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="glass-effect rounded-xl p-2 mb-8">
          <div className="flex space-x-1">
            {[
              { id: 'overview', label: 'Overview', icon: User },
              { id: 'achievements', label: 'Achievements', icon: Award },
              { id: 'skills', label: 'Skills', icon: Target },
              { id: 'activity', label: 'Activity', icon: Clock },
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${activeTab === tab.id ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground hover:bg-accent'}`}>
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {activeTab === 'overview' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="space-y-6">
                <div className="glass-effect rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-4">Recent Labs</h3>
                  <div className="space-y-3">
                    {['SQL Injection Mastery', 'Buffer Overflow Basics', 'Network Reconnaissance'].map((lab) => (
                      <div key={lab} className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                        <div className="flex items-center space-x-3"><Target className="h-5 w-5 text-green-400" /><span>{lab}</span></div>
                        <span className="text-sm text-muted-foreground">Completed</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="glass-effect rounded-xl p-6">
                  <h3 className="text-xl font-semibold mb-4">Progress Overview</h3>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1"><span>Overall Progress</span><span>68%</span></div>
                      <Progress value={68} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1"><span>This Month</span><span>85%</span></div>
                      <Progress value={85} className="[&>div]:bg-blue-500" />
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
            {activeTab === 'achievements' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement, index) => {
                  const Icon = achievement.icon;
                  return (
                    <motion.div key={achievement.name} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5, delay: index * 0.1 }} className={`glass-effect rounded-xl p-6 ${achievement.earned ? 'border-2 border-green-400/30' : 'opacity-60'}`}>
                      <div className="flex items-center space-x-3 mb-3">
                        <Icon className={`h-8 w-8 ${achievement.earned ? 'text-green-400' : 'text-muted-foreground'}`} />
                        <div>
                          <h4 className="font-semibold">{achievement.name}</h4>
                          <p className="text-sm text-muted-foreground">{achievement.description}</p>
                        </div>
                      </div>
                      {achievement.earned && <span className="inline-block px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200 text-xs rounded-full">Earned</span>}
                    </motion.div>
                  );
                })}
              </motion.div>
            )}
            {activeTab === 'skills' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="glass-effect rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-6">Skill Levels</h3>
                <div className="space-y-6">
                  {skills.map((skill, index) => (
                    <motion.div key={skill.name} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{skill.name}</span>
                        <div className="flex items-center space-x-2"><span className="text-sm text-muted-foreground">{skill.category}</span><span className="text-sm font-medium">{skill.level}%</span></div>
                      </div>
                      <Progress value={skill.level} />
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
            {activeTab === 'activity' && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }} className="glass-effect rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-6">Recent Activity</h3>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => {
                    const Icon = getActivityIcon(activity.type);
                    return (
                      <motion.div key={index} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="flex items-center space-x-4 p-3 bg-muted/30 rounded-lg">
                        <Icon className="h-5 w-5 text-blue-400" />
                        <div className="flex-1">
                          <div className="font-medium">{activity.title}</div>
                          <div className="text-sm text-muted-foreground">{activity.time}</div>
                        </div>
                        {activity.points > 0 && <div className="text-green-400 font-medium">+{activity.points} pts</div>}
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            )}
          </div>
          <div className="space-y-6">
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.4 }} className="glass-effect rounded-xl p-6">
              <h3 className="font-semibold mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-muted-foreground">Labs This Week</span><span className="font-medium">8</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Average Score</span><span className="font-medium">87%</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Community Rank</span><span className="font-medium">#156</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Tools Purchased</span><span className="font-medium">12</span></div>
              </div>
            </motion.div>
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.5 }} className="glass-effect rounded-xl p-6">
              <h3 className="font-semibold mb-4">Recommended</h3>
              <div className="space-y-3">
                <div className="p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"><div className="font-medium text-sm">Advanced XSS Lab</div><div className="text-xs text-muted-foreground">Based on your web security skills</div></div>
                <div className="p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"><div className="font-medium text-sm">Network Scanner Pro</div><div className="text-xs text-muted-foreground">Popular in marketplace</div></div>
                <div className="p-3 bg-muted/30 rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"><div className="font-medium text-sm">CTF Competition</div><div className="text-xs text-muted-foreground">Starting this weekend</div></div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
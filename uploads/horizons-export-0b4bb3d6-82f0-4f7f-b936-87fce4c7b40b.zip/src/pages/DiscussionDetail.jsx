import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';
import { useCommunity } from '@/contexts/CommunityContext';
import { useToast } from '@/components/ui/use-toast';
import { ThumbsUp, MessageCircle, Bookmark, Share2, Send } from 'lucide-react';

const DiscussionDetail = () => {
  const { discussionId } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const { getDiscussion, addComment, toggleLike, isLiked, toggleSave, isSaved } = useCommunity();
  const [newComment, setNewComment] = useState('');
  
  const discussion = getDiscussion(discussionId);

  const handleProtectedAction = (action) => {
    if (!user) {
      toast({ title: "Login Required", description: "Please log in to interact.", variant: "destructive" });
      navigate('/login');
      return;
    }
    action();
  };
  
  const handleShare = () => {
    toast({
      title: "Link Copied!",
      description: "Discussion link copied to clipboard (simulated)."
    });
  }

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    handleProtectedAction(() => {
      if (newComment.trim()) {
        addComment(discussion.id, newComment);
        setNewComment('');
        toast({ title: "Comment Posted!", description: "Your comment is now live." });
      }
    });
  };

  if (!discussion) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <h1 className="text-2xl font-bold">Discussion not found</h1>
        <Link to="/community" className="mt-4"><Button>Back to Community</Button></Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <div className="glass-effect rounded-xl p-8 mb-8">
            <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-md mb-4 inline-block">{discussion.category}</span>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{discussion.title}</h1>
            <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-6">
              <span>By <span className="font-semibold text-primary">{discussion.author}</span></span>
              <span>{discussion.timeAgo}</span>
            </div>
            <p className="text-lg text-muted-foreground mb-8">{discussion.content}</p>
            <div className="flex items-center justify-between border-t border-border pt-4">
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Button variant="ghost" size="sm" onClick={() => handleProtectedAction(() => toggleLike(discussion.id))}><ThumbsUp className={`mr-2 h-4 w-4 ${isLiked(discussion.id) ? 'fill-blue-500 text-blue-500' : ''}`} />{discussion.likes}</Button>
                <Button variant="ghost" size="sm"><MessageCircle className="mr-2 h-4 w-4" />{discussion.replies}</Button>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" onClick={() => handleProtectedAction(() => toggleSave(discussion.id))}><Bookmark className={`h-4 w-4 ${isSaved(discussion.id) ? 'fill-yellow-400 text-yellow-500' : ''}`} /></Button>
                <Button size="sm" variant="outline" onClick={handleShare}><Share2 className="h-4 w-4" /></Button>
              </div>
            </div>
          </div>

          <div className="glass-effect rounded-xl p-8 mb-8">
            <h2 className="text-2xl font-bold mb-6">Comments ({discussion.comments.length})</h2>
            <form onSubmit={handleCommentSubmit} className="flex gap-4 mb-8">
              <Textarea placeholder={user ? "Add your comment..." : "Please log in to comment"} value={newComment} onChange={(e) => setNewComment(e.target.value)} disabled={!user} />
              <Button type="submit" disabled={!user || !newComment.trim()}><Send className="h-4 w-4" /></Button>
            </form>
            <div className="space-y-6">
              {discussion.comments.map((comment, index) => (
                <motion.div key={index} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: index * 0.1 }} className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex-shrink-0"></div>
                  <div>
                    <p className="font-semibold text-primary">{comment.author}</p>
                    <p className="text-muted-foreground">{comment.text}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default DiscussionDetail;
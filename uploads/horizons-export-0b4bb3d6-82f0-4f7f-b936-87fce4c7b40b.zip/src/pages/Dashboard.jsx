import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { 
  Terminal, 
  Shield, 
  Users, 
  TrendingUp, 
  Clock, 
  Star,
  Play,
  Code,
  Zap,
  Target,
  Activity,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { labs } from '@/data/labsData';
import { tools } from '@/data/marketplaceData';

const Dashboard = () => {
  const stats = [
    { label: 'Active Labs', value: '24', icon: Terminal, color: 'text-green-400' },
    { label: 'Community Members', value: '15.2K', icon: Users, color: 'text-blue-400' },
    { label: 'Tools Available', value: '1,847', icon: Code, color: 'text-purple-400' },
    { label: 'Success Rate', value: '94%', icon: TrendingUp, color: 'text-orange-400' },
  ];

  const recentLabs = labs.slice(0, 4);
  const featuredTools = tools.filter(t => t.isFeatured).slice(0, 3);

  return (
    <div className="min-h-screen bg-background">
      <section className="relative overflow-hidden py-20 lg:py-32 px-4">
        <div className="absolute inset-0 matrix-bg opacity-30"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 text-shadow">
              Welcome to{' '}
              <span className="bg-gradient-to-r from-green-400 via-blue-400 to-purple-400 bg-clip-text text-transparent">
                PentraX
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
              The ultimate cybersecurity collaboration hub for ethical hackers, penetration testers, and security professionals.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/labs">
                <Button size="lg" className="cyber-glow w-full sm:w-auto">
                  <Play className="mr-2 h-5 w-5" />
                  Start Hacking
                </Button>
              </Link>
              <Link to="/documentation">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  <Shield className="mr-2 h-5 w-5" />
                  View Documentation
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="glass-effect rounded-xl p-4 md:p-6 text-center hover:scale-105 transition-transform duration-200"
                >
                  <Icon className={`h-6 md:h-8 w-6 md:w-8 mx-auto mb-3 ${stat.color}`} />
                  <div className="text-2xl md:text-3xl font-bold mb-1">{stat.value}</div>
                  <div className="text-xs md:text-sm text-muted-foreground">{stat.label}</div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8">
            <h2 className="text-3xl font-bold mb-4 sm:mb-0">Recent Labs</h2>
            <Link to="/labs">
              <Button variant="outline">View All Labs</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {recentLabs.map((lab, index) => (
              <Link to={`/labs/${lab.id}`} key={lab.id}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="glass-effect rounded-xl p-6 h-full hover:scale-105 transition-all duration-200 cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-3">
                    <Target className="h-6 w-6 text-green-400" />
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      lab.difficulty === 'Beginner' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' :
                      lab.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200' :
                      'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                    }`}>
                      {lab.difficulty}
                    </span>
                  </div>
                  <h3 className="font-semibold mb-2 text-base md:text-lg">{lab.name}</h3>
                  <p className="text-sm text-muted-foreground mb-3">{lab.category}</p>
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Clock className="h-4 w-4 mr-1" />
                    {lab.duration}
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8">
            <h2 className="text-3xl font-bold mb-4 sm:mb-0">Featured Tools</h2>
            <Link to="/marketplace">
              <Button variant="outline">Browse Marketplace</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {featuredTools.map((tool, index) => (
              <motion.div
                key={tool.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="glass-effect rounded-xl p-6 h-full hover:scale-105 transition-all duration-200 cursor-pointer"
              >
                <div className="flex items-center justify-between mb-3">
                  <Code className="h-6 w-6 text-blue-400" />
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    <span className="text-sm">{tool.rating}</span>
                  </div>
                </div>
                <h3 className="font-semibold mb-1 text-base md:text-lg">{tool.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">by {tool.author}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold text-green-400">${tool.price}</span>
                  <Button size="sm">Get Tool</Button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-8">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Link to="/terminal/practice">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="glass-effect rounded-xl p-8 cursor-pointer h-full"
              >
                <Terminal className="h-10 md:h-12 w-10 md:w-12 text-green-400 mx-auto mb-4" />
                <h3 className="text-lg md:text-xl font-semibold mb-2">Launch Terminal</h3>
                <p className="text-muted-foreground text-sm md:text-base">Access your Ubuntu terminal</p>
              </motion.div>
            </Link>
            
            <Link to="/community">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="glass-effect rounded-xl p-8 cursor-pointer h-full"
              >
                <Activity className="h-10 md:h-12 w-10 md:w-12 text-blue-400 mx-auto mb-4" />
                <h3 className="text-lg md:text-xl font-semibold mb-2">Join Discussion</h3>
                <p className="text-muted-foreground text-sm md:text-base">Connect with the community</p>
              </motion.div>
            </Link>
            
            <Link to="/profile">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="glass-effect rounded-xl p-8 cursor-pointer h-full"
              >
                <Award className="h-10 md:h-12 w-10 md:w-12 text-purple-400 mx-auto mb-4" />
                <h3 className="text-lg md:text-xl font-semibold mb-2">View Achievements</h3>
                <p className="text-muted-foreground text-sm md:text-base">Track your progress</p>
              </motion.div>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Dashboard;
